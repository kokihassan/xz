# [k-namapi V7 (Final Version)](https://telegram.me/saad7m)

**An advanced and powerful administration bot based on NEW API

💡 اهلا وسهلا بكم في سورس بوت كينام الذكي 💡

ملاحظه : التحديث والتطوير مستمر حول السورس ‼️

* * *

## Commands |
## ⭐️💎 الاوامر
| help | just send help in your group and get the commands |

| help | ارسل امر مساعده لعرض الاوامر داخل المجموعه |او اكتب الاوامر|

**الاوامر تعمل بدون [!/#]

* * *

# Installation
```sh
# مع كل امر اضغط انتر. ⭐️💎
➖➖➖➖➖➖➖➖➖➖➖➖
🔹 cd $HOME
➖➖➖➖➖➖➖➖➖➖➖➖
🔹 git clone https://github.com/saadmzed/k-namapi.git
➖➖➖➖➖➖➖➖➖➖➖➖
🔹 cd k-namapi
➖➖➖➖➖➖➖➖➖➖➖➖
🔹 chmod +x k-nam.sh
➖➖➖➖➖➖➖➖➖➖➖➖
🔹 ./k-nam.sh install
➖➖➖➖➖➖➖➖➖➖➖➖
#ضع توكن البوت سطر 3 ايدي المطور في سطر 5 و 186 bot.lua ملف bot افتح مجلد 
➖➖➖➖➖➖➖➖➖➖➖➖
🔹 ./k-nam.sh 
➖➖➖➖➖➖➖➖➖➖➖➖

💎 ثم وضع ايدي المطور الثاني او0 بالترمنال ومبروك 💎

💡 vps لتشغيل السورس على سرفر 💡:
cd k-namapi
chmod 777 k-auto.sh
tmux
./k-auto.sh
```
### One command
لتنصيب السورس بكود واحد  :
```sh
cd $HOME && git clone https://github.com/saadmzed/k-namapi.git && cd k-namapi && chmod +x k-nam.sh && ./k-nam.sh install && ./k-nam.sh

* * *

# Support and Development

More information [k-nam Global Chat](https://telegram.me/joinchat/AAAAAD25mIzUH_IQvF8HsQ) كروب الدعم 

# Special thanks to
# شكر خاص الى ⭐️💎
[@MrHalix](https://github.com/MrHalix)

[@Vysheng](https://github.com/vysheng)

[@BeyondTeam](https://t.me/BeyondTeam)

* * *

# Developers!
# ⭐️💎 مطور السورس
[saadmzed](https://github.com/saadmzed) ([Telegram](https://telegram.me/saad7m))


### Our Telegram channel: من قضلك تابع قنواتي من اجل التحديثات ⭐️💎

[@kenamch](https://telegram.me/kenamch)

### Our Telegram channel2:

[k-nam Development Forum](https:/te.me/kenam_ch)
